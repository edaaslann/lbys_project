import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';
import 'screens/login_screen.dart';
import 'screens/home_screen.dart';
import 'screens/doktor_home.dart';
import 'screens/laborant_home.dart';
import 'screens/yonetici_home.dart';
import 'screens/manage_users.dart';
import 'screens/add_patient_screen.dart';



void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'LBYS',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      initialRoute: '/', // Başlangıçta gösterilecek route
      routes: {
        '/': (context) => const LoginScreen(),  
        '/home': (context) => const HomeScreen(),  // Girişten sonra yönlenecek ekran
         '/doktor': (context) => const DoktorHome(),
         '/laborant': (context) => const LaborantHome(),
         '/yonetici': (context) => const YoneticiHome(),
         '/manage-users': (context) => const ManageUsersScreen(),
         '/add_patient': (context) => const AddPatientScreen(),
         '/login': (context) => const LoginScreen(), 

      },
    );
  }
}
