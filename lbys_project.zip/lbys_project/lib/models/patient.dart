//firestoredan gelen verileri sınıfa dönüştürür. veriyi firestore a kaydederken map yapısına çevirir
class Patient {
  final String name;
  final String tc;
  final String testType;
  final List<Map<String, dynamic>> results;
  final String assignedLaborant;
  final String assignedDoctor;

  Patient({
    required this.name,
    required this.tc,
    required this.testType,
    required this.results,
    required this.assignedLaborant,
    required this.assignedDoctor,
  });

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'tc': tc,
      'testType': testType,
      'results': results,
      'assignedLaborant': assignedLaborant,
      'assignedDoctor': assignedDoctor,
      "seenByDoctor": false,
    };
  }

  factory Patient.fromMap(Map<String, dynamic> map) {
    return Patient(
      name: map['name'] ?? '',
      tc: map['tc'] ?? '',
      testType: map['testType'] ?? '',
      results: List<Map<String, dynamic>>.from(map['results'] ?? []),
      assignedLaborant: map['assignedLaborant'] ?? '',
      assignedDoctor: map['assignedDoctor'] ?? '',
      
    );
  }
}


