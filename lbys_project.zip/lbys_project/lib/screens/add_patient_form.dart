import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class AddPatientForm extends StatefulWidget {
  const AddPatientForm({super.key});

  @override
  State<AddPatientForm> createState() => _AddPatientFormState();
}

class _AddPatientFormState extends State<AddPatientForm> {
  final _formKey = GlobalKey<FormState>();
  final _nameCtrl = TextEditingController();
  final _tcCtrl = TextEditingController();

  String _testType = 'Kan Testi';

  @override
  void dispose() {
    _nameCtrl.dispose();
    _tcCtrl.dispose();
    super.dispose();
  }

  // En az hastaya sahip laborant seçilir
  Future<String?> _findAvailableLaborantUID() async {
    final laborants = await FirebaseFirestore.instance
        .collection('users')
        .where('role', isEqualTo: 'laborant')
        .get();

    if (laborants.docs.isEmpty) return null;

    final laborantUIDs = laborants.docs.map((doc) => doc.id).toList();
    Map<String, int> laborantPatientCount = {};

    for (var uid in laborantUIDs) {
      final count = await FirebaseFirestore.instance
          .collection('patients')
          .where('assignedLaborant', isEqualTo: uid)
          .count()
          .get();
      laborantPatientCount[uid] = count.count ?? 0;
    }

    laborantUIDs.sort((a, b) => laborantPatientCount[a]!.compareTo(laborantPatientCount[b]!));

    return laborantUIDs.first;
  }

  // Hasta kaydetme
  Future<void> _savePatient() async {
    if (!_formKey.currentState!.validate()) return;

    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;

    final assignedLaborantUID = await _findAvailableLaborantUID();

    if (assignedLaborantUID == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Aktif laborant bulunamadı. Lütfen daha sonra tekrar deneyin.'),
          backgroundColor: Colors.redAccent,
        ),
      );
      return;
    }

    await FirebaseFirestore.instance.collection('patients').add({
      'name': _nameCtrl.text.trim(),
      'tc': _tcCtrl.text.trim(),
      'testType': _testType,
      'results': [], // Parametre yok, laborant dolduracak
      'assignedDoctor': uid,
      'assignedLaborant': assignedLaborantUID,
      'createdAt': FieldValue.serverTimestamp(),
      'seenByDoctor': false,
    });

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Hasta eklendi')),
    );

    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {

    return Padding(
      padding: const EdgeInsets.all(20),
      child: Form(
        key: _formKey,
        child: ListView(
          children: [
            // Ad Soyad
            TextFormField(
              controller: _nameCtrl,
              decoration: InputDecoration(
                labelText: 'Ad Soyad',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                prefixIcon: const Icon(Icons.person),
              ),
              validator: (v) => v == null || v.isEmpty ? 'Ad Soyad gerekli' : null,
            ),
            const SizedBox(height: 16),

            // TC Kimlik
            TextFormField(
              controller: _tcCtrl,
              decoration: InputDecoration(
                labelText: 'TC Kimlik No',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                prefixIcon: const Icon(Icons.badge),
              ),
              keyboardType: TextInputType.number,
              validator: (v) => v == null || v.isEmpty ? 'TC gerekli' : null,
            ),
            const SizedBox(height: 16),

            // Test Türü Seçimi
            DropdownButtonFormField<String>(
              value: _testType,
              decoration: InputDecoration(
                labelText: 'Test Türü',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
              items: const [
                DropdownMenuItem(value: 'Kan Testi', child: Text('Kan Testi')),
                DropdownMenuItem(value: 'İdrar Testi', child: Text('İdrar Testi')),
              ],
              onChanged: (val) {
                setState(() {
                  _testType = val!;
                });
              },
            ),
            const SizedBox(height: 30),

            // Kaydet Butonu
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: _savePatient,
                icon: const Icon(Icons.save),
                label: const Text('Kaydet'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue.shade600,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
