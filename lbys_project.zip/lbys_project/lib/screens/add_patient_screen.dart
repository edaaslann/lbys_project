import 'package:flutter/material.dart';
import 'add_patient_form.dart';

class AddPatientScreen extends StatelessWidget {
  const AddPatientScreen({super.key});

  @override
  Widget build(BuildContext context) {
    //sayfa iskeleti
    return Scaffold(
      appBar: AppBar(
        title: Text('Yeni Hasta Ekle'),
        centerTitle: true,
      ),
      body: AddPatientForm(),
    );
  }
}
