import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'patient_detail_page.dart';

class DoctorForm extends StatefulWidget {
  final String currentUserUID;

  const DoctorForm({super.key, required this.currentUserUID});

  @override
  State<DoctorForm> createState() => _DoctorFormState();
}
//Bu, state içeren bir widget’tır. Çünkü kullanıcı arama yapar, filtre seçer, tarih aralığı uygular ve bu eylemler ekranda değişikliklere neden olur.
class _DoctorFormState extends State<DoctorForm> {
  int _selectedFilter = 0;
  String _searchQuery = '';
  DateTimeRange? _selectedRange;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      //sayfanın üst kısmındaki başlık çubuğu
      appBar: AppBar(
        title: const Text('Doktor Paneli'),
        centerTitle: true,
        backgroundColor: Colors.teal,
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: "Çıkış Yap",
            onPressed: () async {
              await FirebaseAuth.instance.signOut();
              if (context.mounted) {
                Navigator.pushReplacementNamed(context, '/');
              }
            },
          ),
        ],
      ),
      body: Column(
        children: [
          // Arama kutusu + Tarih ikonları
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    decoration: const InputDecoration(
                      labelText: 'İsim veya TC ile ara',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.search),
                    ),
                    onChanged: (value) {
                      setState(() {
                        _searchQuery = value.toLowerCase();
                      });
                    },
                  ),
                ),
                const SizedBox(width: 8),
                IconButton(
                  icon: const Icon(Icons.date_range),
                  tooltip: "Tarih Aralığı Seç",
                  onPressed: () async {
                    DateTimeRange? picked = await showDateRangePicker(
                      context: context,
                      firstDate: DateTime(2024, 1),
                      lastDate: DateTime.now().add(const Duration(days: 1)),
                    );
                    if (picked != null) {
                      setState(() {
                        _selectedRange = picked;
                      });
                    }
                  },
                ),
                if (_selectedRange != null)
                  IconButton(
                    icon: const Icon(Icons.clear, color: Colors.red),
                    tooltip: "Tarih filtresini sıfırla",
                    onPressed: () {
                      setState(() {
                        _selectedRange = null;
                      });
                    },
                  ),
              ],
            ),
          ),

          // Filtre butonları
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                //sonucu girilmiş girilmemiş ve tüm hastalar olarak sıralama yaptığımız
                _buildFilterButton("Tümü", 0),
                _buildFilterButton("Bekleyen", 1),
                _buildFilterButton("Tamamlanan", 2),
              ],
            ),
          ),

          const SizedBox(height: 10),

          // Hasta Listesi
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              // yalnızca bu doktora atanmış hastalar dinamik olarak alınır.StreamBuilder, veri geldikçe UI’yi otomatik günceller.
              stream: FirebaseFirestore.instance
                  .collection('patients')
                  .where('assignedDoctor', isEqualTo: widget.currentUserUID)
                  .snapshots(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }

                if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                  return const Center(child: Text('Henüz hasta kaydı yok.'));
                }

                final patients = snapshot.data!.docs.where((doc) {
                  final data = doc.data() as Map<String, dynamic>;

                  final name = (data['name'] ?? '').toString().toLowerCase();
                  final tc = (data['tc'] ?? '').toString().toLowerCase();

                  if (_searchQuery.isNotEmpty &&
                      !name.contains(_searchQuery) &&
                      !tc.contains(_searchQuery)) {
                    return false;
                  }

                  final results = (data['results'] as List?)
                          ?.cast<Map<String, dynamic>>() ??
                      [];

                  if (_selectedFilter == 1) {
                    return results.isEmpty ||
                        results.every((r) =>
                            (r['value'] as String?)?.trim().isEmpty ?? true);
                  } else if (_selectedFilter == 2) {
                    return results.any((r) =>
                        (r['value'] as String?)?.trim().isNotEmpty ?? false);
                  }

                  if (_selectedRange != null) {
                    final createdAt = data['createdAt'];
                    if (createdAt is Timestamp) {
                      final created = createdAt.toDate();
                      if (created.isBefore(_selectedRange!.start) ||
                          created.isAfter(_selectedRange!.end)) {
                        return false;
                      }
                    } else {
                      return false;
                    }
                  }

                  return true;
                }).toList();

                if (patients.isEmpty) {
                  return const Center(child: Text('Eşleşen hasta bulunamadı.'));
                }

                return ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: patients.length,
                  itemBuilder: (context, index) {
                    final patient =
                        patients[index].data() as Map<String, dynamic>;

                    return InkWell(
                      onTap: () async {
                        //hasta detay sayfasına gönderme
                        final docId = patients[index].id;
                        await FirebaseFirestore.instance
                            .collection('patients')
                            .doc(docId)
                            .update({'seenByDoctor': true});

                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) =>
                                PatientDetailPage(patient: patient),
                          ),
                        );
                      },
                      child: Card(
                        elevation: 4,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        margin: const EdgeInsets.only(bottom: 16),
                        child: ListTile(
                          title: Row(
                            children: [
                              Expanded(
                                child: Text(
                                  patient['name'] ?? 'İsim yok',
                                  style: const TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                              if (patient['seenByDoctor'] != true)
                              //yeni hastaların yanında kırmızı etiketle yeni yazısı çıkar
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 8, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: Colors.redAccent,
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  child: const Text(
                                    'Yeni',
                                    style: TextStyle(
                                        color: Colors.white, fontSize: 12),
                                  ),
                                ),
                            ],
                          ),
                          subtitle: Text("TC: ${patient['tc'] ?? 'Yok'}"),
                          trailing: const Icon(Icons.arrow_forward_ios),
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterButton(String label, int value) {
    return ElevatedButton(
      onPressed: () {
        setState(() {
          _selectedFilter = value;
        });
      },
      style: ElevatedButton.styleFrom(
        backgroundColor:
            _selectedFilter == value ? Colors.teal : Colors.grey[300],
        foregroundColor:
            _selectedFilter == value ? Colors.white : Colors.black,
      ),
      child: Text(label),
    );
  }
}
