import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'doktor_form.dart'; 

class DoktorHome extends StatelessWidget {
  const DoktorHome({super.key});

  @override
  Widget build(BuildContext context) {
    final String currentUserUID = FirebaseAuth.instance.currentUser!.uid;

    return Scaffold(
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.teal,
        onPressed: () {
          Navigator.pushNamed(context, '/add_patient');
        },
        child: const Icon(Icons.add),
        tooltip: 'Yeni Hasta Ekle',
      ),
      body: DoctorForm(currentUserUID: currentUserUID), 
    );
  }
}
