import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class TestResultForm extends StatefulWidget {
  //statefulwidget ile kullanıcı etkileşimine bağlı UI değişiklikleri oluyor. (hasta/test seçimi vs.)
  final String selectedTest;
  final String? selectedPatientId;
  final List<Map<String, dynamic>> testResults;
  final List<DropdownMenuItem<String>> patientItems;
  final void Function(String?) onPatientChanged;
  final void Function(String?) onTestChanged;
  final VoidCallback onSave;

  const TestResultForm({
    super.key,
    required this.selectedTest,
    required this.selectedPatientId,
    required this.testResults,
    required this.patientItems,
    required this.onPatientChanged,
    required this.onTestChanged,
    required this.onSave,
  });

  @override
  State<TestResultForm> createState() => _TestResultFormState();
}

class _TestResultFormState extends State<TestResultForm> {
  bool isLoadingDeviceData = false;

  Future<void> _fetchDeviceData() async {
    //device_results koleksiyonundan verileri alıyor
    if (widget.selectedPatientId == null) return;

    setState(() => isLoadingDeviceData = true);

    try {
      final snapshot = await FirebaseFirestore.instance
          .collection('device_results')
          .where('patientId', isEqualTo: widget.selectedPatientId)
          .limit(1)
          .get();

      if (snapshot.docs.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Cihaz verisi bulunamadı.")),
        );
        setState(() => isLoadingDeviceData = false);
        return;
      }

      final data = snapshot.docs.first.data();
      final List deviceResults = data['results'];

      for (var param in widget.testResults) {
        final match = deviceResults.firstWhere(
          (e) => e['param'] == param['param'],
          orElse: () => {},
        );
        if (match.isNotEmpty) {
          param['controller'].text = match['value'].toString();
        }
      }

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Cihaz verileri başarıyla yüklendi.")),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Veri çekme hatası: $e")),
      );
    } finally {
      setState(() => isLoadingDeviceData = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final themeColor = Colors.teal.shade700;

    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Column(
                children: [
                  Icon(Icons.biotech, size: 50, color: themeColor),
                  const SizedBox(height: 8),
                  Text(
                    'Laboratuvar Sonuç Girişi',
                    style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: themeColor),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            Card(
              //bir widgettir.Hasta ve test seçimi içeren kısımlar bu kart içine alınmış
              elevation: 3,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    DropdownButtonFormField<String>(
                      decoration: const InputDecoration(
                        labelText: 'Hasta Seç',
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.person),
                      ),
                      value: widget.selectedPatientId,
                      items: widget.patientItems,
                      onChanged: widget.onPatientChanged,
                    ),
                    const SizedBox(height: 16),
                    DropdownButtonFormField<String>(
                      decoration: const InputDecoration(
                        labelText: 'Test Türü',
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.science),
                      ),
                      value: widget.selectedTest,
                      items: const [
                        DropdownMenuItem(value: 'Kan Testi', child: Text('Kan Testi')),
                      ],
                      onChanged: widget.onTestChanged,
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 16),

            Align(
              alignment: Alignment.centerRight,
              child: ElevatedButton.icon(
                onPressed: isLoadingDeviceData ? null : _fetchDeviceData,
                //cihazdan verileri almak için buton
                icon: const Icon(Icons.memory),
                label: const Text("Makineden Veri Al"),
                style: ElevatedButton.styleFrom(
                  backgroundColor: themeColor,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
              ),
            ),

            const SizedBox(height: 16),

            ...widget.testResults.map((param) {
              final range = param['range']?.toString();
              final unit = param['unit'] ?? '';
              final controller = param['controller'];

              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 6),
                child: TextField(
                  controller: controller,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  inputFormatters: [
                    FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d*')),
                  ],
                  decoration: InputDecoration(
                    labelText: '${param['param']} ($unit)',
                    helperText: 'Referans: $range',
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                    filled: true,
                    fillColor: Colors.white,
                  ),
                ),
              );
            }).toList(),

            const SizedBox(height: 30),

            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: widget.onSave,
                icon: const Icon(Icons.save, color: Colors.white),
                label: const Text('Sonuçları Kaydet', style: TextStyle(color: Colors.white)),
                style: ElevatedButton.styleFrom(
                  backgroundColor: themeColor,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  elevation: 3,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
