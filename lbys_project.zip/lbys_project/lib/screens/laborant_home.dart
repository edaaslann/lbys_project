import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'laborant_form.dart';

class LaborantHome extends StatefulWidget {
  const LaborantHome({super.key});

  @override
  State<LaborantHome> createState() => _LaborantHomeState();
}

class _LaborantHomeState extends State<LaborantHome> {
  final String currentUserUID = FirebaseAuth.instance.currentUser!.uid;
  String selectedTest = 'Kan Testi';
  String? selectedPatientId;
  List<Map<String, dynamic>> _testResults = [];
  List<DocumentSnapshot> _patients = [];

  List<Map<String, dynamic>> getTestParams(String testType) {
    if (testType == 'Kan Testi') {
      return [
        {'param': 'Hemoglobin', 'unit': 'g/dL', 'range': '12.0 – 16.0', 'controller': TextEditingController()},
        {'param': 'Hematokrit', 'unit': '%', 'range': '36 – 47', 'controller': TextEditingController()},
        {'param': 'WBC', 'unit': '10⁹/L', 'range': '4.0 – 10.0', 'controller': TextEditingController()},
        {'param': 'RBC', 'unit': '10¹²/L', 'range': '3.8 – 5.2', 'controller': TextEditingController()},
        {'param': 'Trombosit', 'unit': '10⁹/L', 'range': '150 – 400', 'controller': TextEditingController()},
        {'param': 'MCV', 'unit': 'fL', 'range': '80 – 100', 'controller': TextEditingController()},
        {'param': 'MCH', 'unit': 'pg', 'range': '27 – 33', 'controller': TextEditingController()},
        {'param': 'MCHC', 'unit': 'g/dL', 'range': '32 – 36', 'controller': TextEditingController()},
        {'param': 'RDW', 'unit': '%', 'range': '11.5 – 14.5', 'controller': TextEditingController()},
        {'param': 'Neutrofil', 'unit': '%', 'range': '40 – 60', 'controller': TextEditingController()},
        {'param': 'Lenfosit', 'unit': '%', 'range': '20 – 40', 'controller': TextEditingController()},
      ];
    } else {
      return [];
    }
  }

  @override
  void initState() {
    super.initState();
    _testResults = getTestParams(selectedTest);
  }

  Future<void> _saveResults() async {
    if (selectedPatientId == null) return;

    await FirebaseFirestore.instance.collection('patients').doc(selectedPatientId).update({
      'testType': selectedTest,
      'results': _testResults.map((param) => {
            'param': param['param'],
            'value': param['controller'].text.trim(),
            'unit': param['unit'],
            'range': param['range'],
          }).toList(),
      'assignedLaborant': currentUserUID,
      'updatedAt': FieldValue.serverTimestamp(),
    });

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Test sonuçları kaydedildi')),
    );
  }

  Future<void> _logout() async {
    await FirebaseAuth.instance.signOut();
    Navigator.pushReplacementNamed(context, '/login');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Laborant Paneli'),
        actions: [
          IconButton(
            onPressed: _logout,
            icon: const Icon(Icons.logout),
            tooltip: 'Çıkış Yap',
          )
        ],
      ),
      body: FutureBuilder<QuerySnapshot>(
        future: FirebaseFirestore.instance
            .collection('patients')
            .where('assignedLaborant', isEqualTo: currentUserUID)
            .get(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          _patients = snapshot.data!.docs;

          return TestResultForm(
            selectedTest: selectedTest,
            selectedPatientId: selectedPatientId,
            testResults: _testResults,
            patientItems: _patients.map((doc) {
              final data = doc.data() as Map<String, dynamic>;
              return DropdownMenuItem(
                value: doc.id,
                child: Text(data['name'] ?? 'İsim yok'),
              );
            }).toList(),
            onPatientChanged: (val) => setState(() => selectedPatientId = val),
            onTestChanged: (val) {
              setState(() {
                selectedTest = val!;
                _testResults = getTestParams(val);
              });
            },
            onSave: _saveResults,
          );
        },
      ),
    );
  }
}
