import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:lbys_project/services/auth_service.dart';
import 'login_form.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();

  bool _isLoading = false;
  String? _errorMessage;

  Future<void> _login() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      User? user = await AuthService().signIn(
        email: _emailController.text.trim(),
        password: _passwordController.text.trim(),
      );

      if (user != null) {
        String? role = await AuthService().getUserRole(user.uid);

        if (role == 'doktor') {
          Navigator.pushReplacementNamed(context, '/doktor');
        } else if (role == 'laborant') {
          Navigator.pushReplacementNamed(context, '/laborant');
        } else if (role == 'yonetici') {
          Navigator.pushReplacementNamed(context, '/yonetici');
        } else {
          setState(() {
            _errorMessage = 'Kullanıcı rolü tanımsız.';
          });
        }
      }
    } on FirebaseAuthException catch (e) {
      setState(() {
        switch (e.code) {
          case 'user-not-found':
          case 'wrong-password':
            _errorMessage = 'Kullanıcı adı veya şifre hatalı.';
            break;
          case 'invalid-email':
            _errorMessage = 'Geçersiz e-posta adresi.';
            break;
          case 'user-disabled':
            _errorMessage = 'Bu kullanıcı hesabı devre dışı bırakılmış.';
            break;
          default:
            _errorMessage = 'Giriş başarısız: ${e.message}';
        }
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFE6F2F8), 
      body: LoginForm(
        emailController: _emailController,
        passwordController: _passwordController,
        isLoading: _isLoading,
        onLogin: _login,
        errorMessage: _errorMessage,
      ),
    );
  }
}
