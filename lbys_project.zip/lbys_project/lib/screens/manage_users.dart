import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class ManageUsersScreen extends StatefulWidget {
  const ManageUsersScreen({super.key});

  @override
  State<ManageUsersScreen> createState() => _ManageUsersScreenState();
}

class _ManageUsersScreenState extends State<ManageUsersScreen> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _surnameController = TextEditingController();
  String _selectedRole = 'laborant';

  Future<void> _addUser() async {
    try {
      final UserCredential userCredential = await FirebaseAuth.instance
          .createUserWithEmailAndPassword(
        email: _emailController.text.trim(),
        password: _passwordController.text.trim(),
      );

      final uid = userCredential.user!.uid;

      await FirebaseFirestore.instance.collection('users').doc(uid).set({
        'uid': uid,
        'name': _nameController.text.trim(),
        'surname': _surnameController.text.trim(),
        'email': _emailController.text.trim(),
        'role': _selectedRole,
        'active': true,
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Kullanıcı başarıyla eklendi.")),
      );

      _emailController.clear();
      _passwordController.clear();
      _nameController.clear();
      _surnameController.clear();
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Hata: $e")),
      );
    }
  }

  Future<void> _deleteUser(String uid) async {
    await FirebaseFirestore.instance.collection('users').doc(uid).delete();
  }

  Future<void> _updateUserRole(String uid, String role) async {
    await FirebaseFirestore.instance
        .collection('users')
        .doc(uid)
        .update({'role': role});
  }

  Future<void> _toggleUserAccess(String uid, bool isActive) async {
    await FirebaseFirestore.instance
        .collection('users')
        .doc(uid)
        .update({'active': isActive});
  }

  Future<void> _resetPassword(String email) async {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("$email adresine şifre sıfırlama bağlantısı gönderildi.")),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Kullanıcı Yönetimi"),
        backgroundColor: Colors.teal,
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("Yeni Kullanıcı Ekle", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                TextField(
                  controller: _nameController,
                  decoration: const InputDecoration(labelText: "Ad"),
                ),
                TextField(
                  controller: _surnameController,
                  decoration: const InputDecoration(labelText: "Soyad"),
                ),
                TextField(
                  controller: _emailController,
                  decoration: const InputDecoration(labelText: "E-posta"),
                ),
                TextField(
                  controller: _passwordController,
                  decoration: const InputDecoration(labelText: "Şifre"),
                  obscureText: true,
                ),
                DropdownButtonFormField<String>(
                  value: _selectedRole,
                  decoration: const InputDecoration(labelText: 'Rol'),
                  items: const [
                    DropdownMenuItem(value: 'doktor', child: Text('Doktor')),
                    DropdownMenuItem(value: 'laborant', child: Text('Laborant')),
                  ],
                  onChanged: (value) {
                    if (value != null) {
                      setState(() {
                        _selectedRole = value;
                      });
                    }
                  },
                ),
                const SizedBox(height: 10),
                ElevatedButton(
                  onPressed: _addUser,
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.teal, foregroundColor: Colors.white),
                  child: const Text("Kullanıcı Ekle"),
                ),
              ],
            ),
          ),
          const Divider(),
          const Text("Mevcut Kullanıcılar", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance.collection('users').snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }

                final users = snapshot.data!.docs;

                return ListView.builder(
                  itemCount: users.length,
                  itemBuilder: (context, index) {
                    final userDoc = users[index];
                    final user = userDoc.data() as Map<String, dynamic>;
                    final uid = userDoc.id;
                    final isActive = user['active'] ?? true;
                    final email = user['email'] ?? 'Bilinmiyor';
                    final role = user['role'] ?? 'Belirtilmemiş';
                    final name = user['name'] ?? '';
                    final surname = user['surname'] ?? '';

                    return Card(
                      margin: const EdgeInsets.all(8),
                      child: ListTile(
                        title: Text("$name $surname"),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text("E-posta: $email"),
                            Text("Rol: $role"),
                            Text("Durum: ${isActive ? "Aktif" : "Pasif"}"),
                          ],
                        ),
                        trailing: PopupMenuButton<String>(
                          onSelected: (value) {
                            if (value == 'delete') {
                              _deleteUser(uid);
                            } else if (value == 'reset') {
                              _resetPassword(email);
                            } else if (value == 'toggle') {
                              _toggleUserAccess(uid, !isActive);
                            } else if (value.startsWith('role:')) {
                              final newRole = value.split(':')[1];
                              _updateUserRole(uid, newRole);
                            }
                          },
                          itemBuilder: (context) => [
                            const PopupMenuItem(value: 'reset', child: Text('🔑 Şifre Sıfırla')),
                            const PopupMenuItem(value: 'delete', child: Text('🗑️ Kullanıcıyı Sil')),
                            PopupMenuItem(value: 'toggle', child: Text(isActive ? '🚫 Pasifleştir' : '✅ Aktifleştir')),
                            const PopupMenuDivider(),
                            const PopupMenuItem(value: 'role:doktor', child: Text('🩺 Doktor yap')),
                            const PopupMenuItem(value: 'role:laborant', child: Text('🧪 Laborant yap')),
                          ],
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}