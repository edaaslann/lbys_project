import 'package:flutter/material.dart';
import 'package:printing/printing.dart';
import '../utils/pdf_generator.dart';

class PatientDetailPage extends StatelessWidget {
  final Map<String, dynamic> patient;

  const PatientDetailPage({super.key, required this.patient});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(patient['name'] ?? 'Hasta Detayı'),
        backgroundColor: Colors.teal,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            Text("🧍 İsim: ${patient['name'] ?? 'Yok'}", style: const TextStyle(fontSize: 18)),
            const SizedBox(height: 10),
            Text("🆔 TC: ${patient['tc'] ?? 'Yok'}", style: const TextStyle(fontSize: 18)),
            const SizedBox(height: 10),
            Text("🧪 Test Türü: ${patient['testType'] ?? 'Yok'}", style: const TextStyle(fontSize: 18)),
            const SizedBox(height: 20),
            const Text("📊 Test Sonuçları:", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),

            if (patient['results'] != null)
              ..._buildGroupedResults(patient['results'] as List),

            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () async {
                final pdfBytes = await generatePatientPdf(patient);
                await Printing.layoutPdf(onLayout: (format) async => pdfBytes);
              },
              style: ElevatedButton.styleFrom(backgroundColor: Colors.teal),
              child: const Text("📄 PDF Olarak Görüntüle"),
            ),
          ],
        ),
      ),
    );
  }

  List<Widget> _buildGroupedResults(List results) {
    Map<String, List> grouped = {};

    for (var r in results) {
      final category = r['category'] ?? 'Diğer';
      grouped.putIfAbsent(category, () => []).add(r);
    }

    List<Widget> widgets = [];

    grouped.forEach((category, items) {
      widgets.add(Padding(
        padding: const EdgeInsets.only(top: 12.0, bottom: 4),
        child: Text("📂 $category", style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      ));

      widgets.addAll(items.map((r) {
        final value = double.tryParse(r['value'].toString().replaceAll(',', '.'));
        final rangeStr = r['range']?.toString().replaceAll('–', '-').replaceAll(',', '.');
        double? min;
        double? max;

        bool isOutOfRange = false;

        if (rangeStr != null && rangeStr.contains('-') && value != null) {
          final parts = rangeStr.split('-');
          if (parts.length == 2) {
            min = double.tryParse(parts[0].trim());
            max = double.tryParse(parts[1].trim());
            if (min != null && max != null) {
              isOutOfRange = value < min || value > max;
            }
          }
        }

        return Container(
          margin: const EdgeInsets.symmetric(vertical: 6),
          decoration: BoxDecoration(
            color: isOutOfRange ? Colors.redAccent : Colors.white,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
              color: isOutOfRange ? Colors.red : Colors.grey.shade300,
              width: 1,
            ),
          ),
          child: ListTile(
            title: Text(
              "${r['param']}: ${r['value']} ${r['unit']}",
              style: TextStyle(
                color: isOutOfRange ? Colors.white : Colors.black,
                fontWeight: FontWeight.bold,
              ),
            ),
            subtitle: Text(
              "Referans Aralığı: ${r['range'] ?? 'Belirtilmemiş'}",
              style: TextStyle(
                color: isOutOfRange ? Colors.white.withOpacity(0.9) : Colors.black54,
              ),
            ),
            trailing: isOutOfRange ? const Icon(Icons.warning, color: Colors.white) : null,
          ),
        );
      }));
    });

    return widgets;
  }
}
