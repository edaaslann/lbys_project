import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class SystemReportScreen extends StatefulWidget {
  const SystemReportScreen({super.key});

  @override
  State<SystemReportScreen> createState() => _SystemReportScreenState();
}

class _SystemReportScreenState extends State<SystemReportScreen> {
  int doktorSayisi = 0;
  int laborantSayisi = 0;
  int hastaSayisi = 0;
  bool yukleniyor = true;

  @override
  void initState() {
    super.initState();
    _raporuYukle();
  }

  Future<void> _raporuYukle() async {
    try {
      final usersSnapshot = await FirebaseFirestore.instance.collection('users').get();
      final patientsSnapshot = await FirebaseFirestore.instance.collection('patients').get();

      int doktor = 0;
      int laborant = 0;

      for (var doc in usersSnapshot.docs) {
        final role = doc['role'];
        if (role == 'doktor') doktor++;
        if (role == 'laborant') laborant++;
      }

      setState(() {
        doktorSayisi = doktor;
        laborantSayisi = laborant;
        hastaSayisi = patientsSnapshot.size;
        yukleniyor = false;
      });
    } catch (e) {
      setState(() {
        yukleniyor = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Veri çekilirken hata oluştu: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('📊 Sistem Raporu'),
        backgroundColor: Colors.teal,
      ),
      body: yukleniyor
          ? const Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  const Text(
                    "Genel İstatistikler",
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 20),
                  _raporKart("🩺 Doktor Sayısı", doktorSayisi, Colors.blue),
                  _raporKart("🧪 Laborant Sayısı", laborantSayisi, Colors.orange),
                  _raporKart("👤 Toplam Hasta", hastaSayisi, Colors.green),
                ],
              ),
            ),
    );
  }

  Widget _raporKart(String baslik, int sayi, Color renk) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 10),
      color: renk.withOpacity(0.1),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: renk,
          child: Text(sayi.toString(), style: const TextStyle(color: Colors.white)),
        ),
        title: Text(
          baslik,
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: renk),
        ),
      ),
    );
  }
}
