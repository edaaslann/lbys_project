import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:lbys_project/screens/system_report.dart';
import 'package:lbys_project/screens/manage_users.dart';

class YoneticiForm extends StatefulWidget {
  const YoneticiForm({super.key});

  @override
  State<YoneticiForm> createState() => _YoneticiFormState();
}

class _YoneticiFormState extends State<YoneticiForm> {
  Future<void> _deletePatient(String id) async {
    await FirebaseFirestore.instance.collection('patients').doc(id).delete();
  }

  void _goToUserManagement() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const ManageUsersScreen()),
    );
  }

  void _showSystemReport() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const SystemReportScreen()),
    );
  }

  Future<void> _signOut() async {
    await FirebaseAuth.instance.signOut();
    // login sayfasına yönlendirme
    Navigator.of(context).pushReplacementNamed('/login');
  }

  Future<String> _getUserNameByUID(String uid) async {
    if (uid.isEmpty) return 'Yok';
    try {
      final doc =
          await FirebaseFirestore.instance.collection('users').doc(uid).get();
      if (doc.exists) {
        final data = doc.data()!;
        return "${data['name']} ${data['surname']}";
      } else {
        return 'Bilinmiyor';
      }
    } catch (e) {
      return 'Hata';
    }
  }

  String _formatDate(dynamic date) {
    if (date == null) return 'Bilinmiyor';
    try {
      if (date is Timestamp) {
        return date.toDate().toString();
      } else if (date is String) {
        return date;
      } else {
        return 'Geçersiz tür';
      }
    } catch (_) {
      return 'Hatalı tarih';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Yönetici Paneli'),
        backgroundColor: Colors.teal,
        actions: [
          IconButton(
            icon: const Icon(Icons.manage_accounts),
            onPressed: _goToUserManagement,
            tooltip: 'Kullanıcı Yönetimi',
          ),
          IconButton(
            icon: const Icon(Icons.assessment),
            onPressed: _showSystemReport,
            tooltip: 'Sistem Raporu',
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: _signOut,
            tooltip: 'Çıkış Yap',
          ),
        ],
      ),
      body: Column(
        children: [
          const SizedBox(height: 16),
          const Text(
            'Tüm Hasta Kayıtları',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const Divider(),
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('patients')
                  .orderBy('createdAt', descending: true)
                  .snapshots(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }

                if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                  return const Center(child: Text('Kayıtlı hasta bulunamadı.'));
                }

                final patients = snapshot.data!.docs;

                return ListView.builder(
                  itemCount: patients.length,
                  itemBuilder: (context, index) {
                    final patientDoc = patients[index];
                    final patient =
                        patientDoc.data() as Map<String, dynamic>;

                    return FutureBuilder<List<String>>(
                      future: Future.wait([
                        _getUserNameByUID(patient['assignedLaborant'] ?? ''),
                        _getUserNameByUID(patient['assignedDoctor'] ?? ''),
                      ]),
                      builder: (context, snapshot) {
                        if (!snapshot.hasData) {
                          return const Center(
                              child: CircularProgressIndicator());
                        }

                        final laborantName = snapshot.data![0];
                        final doctorName = snapshot.data![1];

                        return Card(
                          margin: const EdgeInsets.all(10),
                          child: ExpansionTile(
                            title: Text(patient['name'] ?? 'İsim yok'),
                            subtitle: Text(
                              "TC: ${patient['tc'] ?? 'Yok'} - Test Türü: ${patient['testType'] ?? 'Yok'}",
                            ),
                            children: [
                              if (patient['results'] != null)
                                ...List<Widget>.from(
                                  (patient['results'] as List).map(
                                    (r) => ListTile(
                                      title: Text(
                                          "${r['param']}: ${r['value']} ${r['unit']}"),
                                      subtitle: Text(
                                          "Referans Aralığı: ${r['range'] ?? 'Belirtilmemiş'}"),
                                    ),
                                  ),
                                ),
                              const SizedBox(height: 8),
                              Text("Atayan Laborant: $laborantName"),
                              Text("Atanan Doktor: $doctorName"),
                              Text(
                                "Eklenme Tarihi: ${_formatDate(patient['createdAt'])}",
                                style: const TextStyle(
                                    fontSize: 12,
                                    fontStyle: FontStyle.italic),
                              ),
                              IconButton(
                                icon: const Icon(Icons.delete,
                                    color: Colors.red),
                                onPressed: () => _deletePatient(patientDoc.id),
                              ),
                            ],
                          ),
                        );
                      },
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
