import 'package:flutter/material.dart';
import 'package:lbys_project/screens/yonetici_form.dart';

class YoneticiHome extends StatelessWidget {
  const YoneticiHome({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: YoneticiForm(),
    );
  }
}
