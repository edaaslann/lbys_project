import 'dart:typed_data';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:flutter/services.dart' show rootBundle;

Future<Uint8List> generatePatientPdf(Map<String, dynamic> patient) async {
  final pdf = pw.Document();
  final results = (patient['results'] as List?)?.cast<Map<String, dynamic>>() ?? [];
  final font = pw.Font.ttf(await rootBundle.load("assets/fonts/roboto_regular.ttf"));

  pdf.addPage(
    pw.Page(
      pageFormat: PdfPageFormat.a4,
      margin: const pw.EdgeInsets.all(24),
      build: (pw.Context context) {
        return pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Text("Hasta Raporu", style: pw.TextStyle(fontSize: 24, fontWeight: pw.FontWeight.bold, font: font)),
            pw.SizedBox(height: 16),
            pw.Wrap(
              spacing: 40,
              runSpacing: 8,
              children: [
                pw.Text("Hasta Adı: ${patient['name'] ?? ''}", style: pw.TextStyle(font: font)),
                pw.Text("TC: ${patient['tc'] ?? ''}", style: pw.TextStyle(font: font)),
                pw.Text("Test Türü: ${patient['testType'] ?? ''}", style: pw.TextStyle(font: font)),
                pw.Text("Cinsiyet: ${patient['gender'] ?? '-'}", style: pw.TextStyle(font: font)),
                pw.Text("Doğum Tarihi: ${patient['birthDate'] ?? '-'}", style: pw.TextStyle(font: font)),
              ],
            ),
            pw.SizedBox(height: 20),
            pw.Text("Test Sonuçları", style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold, font: font)),
            pw.SizedBox(height: 12),

            pw.TableHelper.fromTextArray(
              headers: ['Test', 'Sonuç', 'Birim', 'Referans'],
              data: results.map((r) {
                final double? value = double.tryParse(r['value'] ?? '');
                final double? min = double.tryParse((r['range'] ?? '').split('-').first.trim());
                final double? max = double.tryParse((r['range'] ?? '').split('-').last.trim());

                String arrow = '';
                if (value != null && min != null && max != null) {
                  if (value < min) arrow = '↓ ';
                  else if (value > max) arrow = '↑ ';
                }

                return [
                  r['param'] ?? '',
                  "$arrow${r['value'] ?? ''}",
                  r['unit'] ?? '',
                  r['range'] ?? '',
                ];
              }).toList(),
              border: pw.TableBorder.all(),
              cellAlignment: pw.Alignment.centerLeft,
              headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold, font: font),
              cellStyle: pw.TextStyle(font: font),
              headerDecoration: const pw.BoxDecoration(color: PdfColors.grey300),
              cellHeight: 30,
              columnWidths: {
                0: const pw.FlexColumnWidth(3),
                1: const pw.FlexColumnWidth(2),
                2: const pw.FlexColumnWidth(2),
                3: const pw.FlexColumnWidth(3),
              },
            ),
            pw.SizedBox(height: 16),

            pw.Text("Açıklamalar:", style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold, font: font)),
            pw.SizedBox(height: 8),
            ...results.where((r) => (r['note'] ?? '').toString().isNotEmpty).map((r) {
              return pw.Padding(
                padding: const pw.EdgeInsets.only(bottom: 8),
                child: pw.Text(
                  "${r['param']}: ${r['note']}",
                  style: pw.TextStyle(fontSize: 12, font: font),
                ),
              );
            }),
          ],
        );
      },
    ),
  );

  return pdf.save();
}
