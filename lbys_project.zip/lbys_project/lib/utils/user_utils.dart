//UID’ye sahip bir kullanıcıyı listeleyeceksin ama ekranda "UID" değil ad-soyad görmek istiyorsan bu fonksiyonu kullanabilirsin
import 'package:cloud_firestore/cloud_firestore.dart';

Future<String> getUserFullName(String uid) async {
  try {
    final doc = await FirebaseFirestore.instance.collection('users').doc(uid).get();
    final data = doc.data();
    if (data != null) {
      return "${data['name'] ?? ''} ${data['surname'] ?? ''}".trim();
    } else {
      return "Bilinmeyen Kullanıcı";
    }
  } catch (e) {
    return "Hata: $e";
  }
}
